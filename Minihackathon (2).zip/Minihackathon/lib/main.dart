
import 'package:flutter/material.dart';

void main() {
  runApp(CleanGramApp());
}

class CleanGramApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'CleanGram',
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int points = 0;

  void addPoints(int weight) {
    setState(() {
      points += weight ~/ 10; // 100g = 10 points logic
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('CleanGram')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text('Total Points: $points',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            TextField(
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: 'Enter waste weight (grams)',
                border: OutlineInputBorder(),
              ),
              onSubmitted: (value) {
                int weight = int.tryParse(value) ?? 0;
                addPoints(weight);
              },
            ),
            SizedBox(height: 20),
            Text('Reward Offers',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            Text('• ₹20 Entry Discount'),
            Text('• 10% Food Discount'),
          ],
        ),
      ),
    );
  }
}
