import 'package:flutter/material.dart';
import '../screens/submission_status_screen.dart';

class SpotDetailScreen extends StatefulWidget {
  final Map<String, dynamic> spot;
  
  SpotDetailScreen({required this.spot});

  @override
  _SpotDetailScreenState createState() => _SpotDetailScreenState();
}

class _SpotDetailScreenState extends State<SpotDetailScreen> {
  final _weightController = TextEditingController();
  bool isSubmitting = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      appBar: AppBar(
        title: Text(widget.spot['name']),
        backgroundColor: Colors.green[600],
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Spot Image
            Container(
              width: double.infinity,
              height: 200,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.green[200]!, Colors.green[400]!],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  widget.spot['image'],
                  style: TextStyle(fontSize: 80),
                ),
              ),
            ),
            
            SizedBox(height: 24),
            
            // Instructions
            Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Help keep this place clean and earn rewards',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: Colors.green[800],
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      'Collect waste from this area and submit the weight to earn reward points. 1 gram = 1 point!',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            SizedBox(height: 24),
            
            // Weight Input Form
            Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Waste Weight (grams)',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 12),
                    TextField(
                      controller: _weightController,
                      decoration: InputDecoration(
                        labelText: 'Enter waste weight',
                        hintText: 'e.g., 200',
                        prefixIcon: Icon(Icons.scale),
                        border: OutlineInputBorder(),
                        suffixText: 'grams',
                      ),
                      keyboardType: TextInputType.number,
                    ),
                    SizedBox(height: 16),
                    
                    // Submit Button
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: isSubmitting ? null : _submitCleaning,
                        icon: isSubmitting 
                            ? SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : Icon(Icons.eco),
                        label: Text(
                          isSubmitting ? 'Submitting...' : 'Submit Cleaning',
                          style: TextStyle(fontSize: 16),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green[600],
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _submitCleaning() async {
    if (_weightController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please enter waste weight')),
      );
      return;
    }

    setState(() => isSubmitting = true);
    
    // Simulate API call
    await Future.delayed(Duration(seconds: 2));
    
    final weight = int.parse(_weightController.text);
    final points = weight; // 1 point per gram
    
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SubmissionStatusScreen(
          weight: weight,
          points: points,
          spotName: widget.spot['name'],
        ),
      ),
    );
    
    setState(() => isSubmitting = false);
  }
}
