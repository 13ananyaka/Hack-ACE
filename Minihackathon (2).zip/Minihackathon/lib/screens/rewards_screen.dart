import 'package:flutter/material.dart';

class RewardsScreen extends StatelessWidget {
  // Mock data for demo
  final List<Map<String, dynamic>> offers = [
    {
      'id': '1',
      'title': '₹20 Entry Fee Discount',
      'description': 'Get ₹20 off on entry fees',
      'type': 'entrance',
      'pointsRequired': 50,
      'isApplied': false,
    },
    {
      'id': '2',
      'title': '10% Food Discount',
      'description': 'Save 10% on local food',
      'type': 'food',
      'pointsRequired': 30,
      'isApplied': false,
    },
    {
      'id': '3',
      'title': 'Free Guide Service',
      'description': 'Complimentary local guide',
      'type': 'service',
      'pointsRequired': 40,
      'isApplied': true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      appBar: AppBar(
        title: Text('Rewards & Offers'),
        backgroundColor: Colors.green[600],
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // Info Banner
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(16),
            color: Colors.green[100],
            child: Column(
              children: [
                Text(
                  'Available Points: 40',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.green[800],
                  ),
                ),
                Text(
                  'Offers provided by local authority',
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.green[600],
                  ),
                ),
              ],
            ),
          ),
          
          // Offers List
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(16),
              itemCount: offers.length,
              itemBuilder: (context, index) {
                final offer = offers[index];
                return Card(
                  margin: EdgeInsets.only(bottom: 16),
                  elevation: 4,
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            // Offer Icon
                            Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                color: _getOfferColor(offer['type']),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Center(
                                child: Icon(
                                  _getOfferIcon(offer['type']),
                                  color: Colors.white,
                                  size: 24,
                                ),
                              ),
                            ),
                            SizedBox(width: 16),
                            
                            // Offer Details
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    offer['title'],
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    offer['description'],
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.grey[600],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 12),
                        
                        // Points Required
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Points Required: ${offer['pointsRequired']}',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w500,
                                color: Colors.grey[700],
                              ),
                            ),
                            
                            // Status Badge
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: offer['isApplied'] ? Colors.grey[400] : Colors.orange[600],
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                offer['isApplied'] ? 'Applied' : 'Claim',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Color _getOfferColor(String type) {
    switch (type) {
      case 'entrance':
        return Colors.blue[600]!;
      case 'food':
        return Colors.orange[600]!;
      case 'service':
        return Colors.purple[600]!;
      default:
        return Colors.grey[600]!;
    }
  }

  IconData _getOfferIcon(String type) {
    switch (type) {
      case 'entrance':
        return Icons.local_activity;
      case 'food':
        return Icons.restaurant;
      case 'service':
        return Icons.tour;
      default:
        return Icons.card_giftcard;
    }
  }
}
