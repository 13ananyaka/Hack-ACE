import 'package:flutter/material.dart';

class SubmissionStatusScreen extends StatefulWidget {
  final int weight;
  final int points;
  final String spotName;
  
  SubmissionStatusScreen({
    required this.weight,
    required this.points,
    required this.spotName,
  });

  @override
  _SubmissionStatusScreenState createState() => _SubmissionStatusScreenState();
}

class _SubmissionStatusScreenState extends State<SubmissionStatusScreen> {
  bool isApproved = false;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _simulateApproval();
  }

  void _simulateApproval() async {
    // Simulate approval process
    await Future.delayed(Duration(seconds: 3));
    
    setState(() {
      isLoading = false;
      isApproved = true; // Auto-approve for demo
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      appBar: AppBar(
        title: Text('Submission Status'),
        backgroundColor: Colors.green[600],
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Card(
            elevation: 8,
            child: Padding(
              padding: EdgeInsets.all(32),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Status Icon
                  Container(
                    width: 100,
                    height: 100,
                    decoration: BoxDecoration(
                      color: isLoading ? Colors.grey[300] : Colors.green[100],
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: isLoading
                          ? CircularProgressIndicator(
                              strokeWidth: 4,
                              valueColor: AlwaysStoppedAnimation<Color>(Colors.green[600]!),
                            )
                          : Icon(
                              Icons.check_circle,
                              size: 60,
                              color: Colors.green[600],
                            ),
                    ),
                  ),
                  
                  SizedBox(height: 24),
                  
                  // Status Text
                  Text(
                    isLoading ? 'Pending Approval' : 'Approved ✅',
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: isLoading ? Colors.grey[600] : Colors.green[600],
                    ),
                  ),
                  
                  SizedBox(height: 16),
                  
                  // Points Earned
                  if (!isLoading && isApproved) ...[
                    Text(
                      'You earned $points points!',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.green[800],
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Weight: ${weight}g',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[600],
                      ),
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Location: $spotName',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                  
                  SizedBox(height: 32),
                  
                  // Action Buttons
                  if (!isLoading && isApproved) ...[
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          Navigator.popUntil(
                            context,
                            (route) => route.isFirst,
                          );
                        },
                        icon: Icon(Icons.home),
                        label: Text(
                          'Back to Home',
                          style: TextStyle(fontSize: 16),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.green[600],
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton.icon(
                        onPressed: () {
                          _shareAchievement();
                        },
                        icon: Icon(Icons.share),
                        label: Text(
                          'Share Achievement',
                          style: TextStyle(fontSize: 16),
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue[600],
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _shareAchievement() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Achievement shared! 🎉')),
    );
  }
}
