import 'package:flutter/material.dart';
import '../screens/spot_detail_screen.dart';

class SpotsListScreen extends StatelessWidget {
  // Mock data for demo
  final List<Map<String, dynamic>> touristSpots = [
    {
      'id': '1',
      'name': 'Gokarna Rural Beach',
      'district': 'Uttara Kannada',
      'rating': 4.2,
      'image': '🏖️',
    },
    {
      'id': '2',
      'name': 'Honnemaradu Lake',
      'district': 'Shivamogga',
      'rating': 4.5,
      'image': '🏞️',
    },
    {
      'id': '3',
      'name': 'Banavasi Heritage Village',
      'district': 'Uttara Kannada',
      'rating': 4.0,
      'image': '🏘️',
    },
    {
      'id': '4',
      'name': 'Coorg Coffee Plantations',
      'district': 'Kodagu',
      'rating': 4.3,
      'image': '☕',
    },
    {
      'id': '5',
      'name': 'Hampi Ancient Ruins',
      'district': 'Ballari',
      'rating': 4.6,
      'image': '🏛️',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.green[50],
      appBar: AppBar(
        title: Text('Tourist Spots'),
        backgroundColor: Colors.green[600],
        foregroundColor: Colors.white,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16),
        itemCount: touristSpots.length,
        itemBuilder: (context, index) {
          final spot = touristSpots[index];
          return Card(
            margin: EdgeInsets.only(bottom: 16),
            elevation: 4,
            child: InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SpotDetailScreen(spot: spot),
                  ),
                );
              },
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Row(
                  children: [
                    // Spot Image/Icon
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        color: Colors.green[100],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Center(
                        child: Text(
                          spot['image'],
                          style: TextStyle(fontSize: 30),
                        ),
                      ),
                    ),
                    SizedBox(width: 16),
                    
                    // Spot Details
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            spot['name'],
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 4),
                          Text(
                            spot['district'],
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Icon(Icons.star, color: Colors.amber, size: 16),
                              SizedBox(width: 4),
                              Text(
                                '${spot['rating']}',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              Spacer(),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.green[600],
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Text(
                                  'Clean',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 12,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
