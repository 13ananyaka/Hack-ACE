
# CleanGram – Incentivized Clean Tourism Platform

Theme: Rural Access & Local Empowerment

## Overview
CleanGram is a mobile app that rewards tourists for cleaning rural tourist spots.
Users earn reward points based on waste collected, which can be redeemed as entry or food offers.

## Features (MVP)
- User login (Firebase-ready)
- Rural tourist spot listing
- Clean submission (simulated weight input)
- Reward points calculation
- Offers display

## Tech Stack
- Flutter
- Firebase (Auth + Firestore)
- Optional Blockchain (simulated log)

## How to Run
1. Install Flutter SDK
2. Run `flutter pub get`
3. Run `flutter run`

## Note
IoT smart dustbin & payments are future scope and simulated in this demo.
